package com.example.hagglex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
